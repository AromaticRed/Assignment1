package com.giginatenadze.assignment1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        SavingsAccount acc1 = new SavingsAccount("S101", "გიორგი გ.");
        VIPAccount acc2 = new VIPAccount("V202", "მარიამი ა.");

        acc1.deposit(1000.0);
        acc1.withdraw(300.0);
        acc1.withdraw(600.0);

        acc2.deposit(1000.0);
        acc2.withdraw(50.0);

        acc1.printInfo();
        acc2.printInfo();

        List<Account> accounts = new ArrayList<>();
        accounts.add(acc1);
        accounts.add(acc2);

        for (Account account : accounts) {
            account.deposit(50.0);
            account.printInfo();
        }
    }
}
