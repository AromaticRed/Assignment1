package com.giginatenadze.assignment1;

public class VIPAccount extends Account {

    private final double transactionFee = 2.0;

    public VIPAccount(String accountNumber, String ownerName) {
        super(accountNumber, ownerName);
    }

    @Override
    public void withdraw(double amount) {
        double totalAmount = amount + transactionFee;
        if (getBalance() >= totalAmount && amount > 0) {
            try {
                java.lang.reflect.Field field = Account.class.getDeclaredField("balance");
                field.setAccessible(true);
                double balance = (double) field.get(this);
                balance -= totalAmount;
                field.set(this, balance);
                System.out.println("VIP withdrawal successful. Amount: " + amount + ", Fee: " + transactionFee);
            } catch (Exception e) {
                System.out.println("Error processing VIP withdrawal.");
            }
        } else {
            System.out.println("Withdrawal failed. Insufficient funds or invalid amount.");
        }
    }
}
