package com.giginatenadze.assignment1;

public class SavingsAccount extends Account {

    public SavingsAccount(String accountNumber, String ownerName) {
        super(accountNumber, ownerName);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 500) {
            System.out.println("Withdrawal limit exceeded. Max 500 per transaction.");
        } else {
            super.withdraw(amount);
        }
    }
}
